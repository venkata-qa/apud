package com.microservice.test.accelerator.constants;

public class Headers {

  public static final String COMMON_HEADERS = "headers";
}
