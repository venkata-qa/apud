package com.microservice.test.accelerator.runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/resources/features"},
        glue = {"com.microservice.test.accelerator.stepdefs"},
        tags = "@apitest",
        plugin = {"pretty", "html:target/cucumber/cucumber-report.html", "json:target/cucumber.json",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
        })
public class RunCucumberTest {
}
