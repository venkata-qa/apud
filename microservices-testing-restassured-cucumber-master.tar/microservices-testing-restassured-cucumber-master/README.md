<!-- TABLE OF CONTENTS -->
<details open="open">
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#about-the-project">About microservices testing</a>
      <ul>
        <li><a href="#accelerator-features">Accelerator features</a></li>
      </ul>
    </li>
    <li>
      <a href="#built-with">Built with</a>
    </li>
    <li>
      <a href="#getting-started">Getting started</a>
      	<ul>
        		<li><a href="#prerequisites">Prerequisites</a></li> 
        		<li><a href="#installation">Installation</a></li>       
        </ul>
    </li>
    <li>
    <a href="#usage">Usage</a>
        <ul>
            <li><a href="#writing-a-test">Writing a test</a></li>
            <li><a href="#testing-environment-information">Testing environment information</a></li>
            <li><a href="#api-under-test-information">API test Information</a></li>
            <li><a href="#sample-feature-file-to-understand-the-keywords"> Understanding the keywords</a></li>
            <li><a href="#key-words-used-in-cucumber-feature-files">Key Words used in Cucumber feature files</a></li>
            <li><a href="#running-tests">Running tests</a></li>
            <li><a href="#test-reports">Test reports</a>
                <ul>
                <li><a href="#default-cucumber-report">Default Cucumber report</a>
                <li><a href="#allure-reporting">Allure reporting</a>
                </ul>
            </li>
        </ul>
    </li>
    <li><a href="#faq">FAQs</a></li>
    <li><a href="#contributing">Contributing</a></li>
    <li><a href="#contact">Contact</a></li>
  </ol>
</details>

<!-- ABOUT THE PROJECT -->
## About microservices testing

This accelerator is an API functional automation testing tool used to perform the functional testing of API's based on RestFull or SOAP Service.

API testing is a software testing practice that tests the APIs directly — from their functionality, reliability and performance, to security. API testing effectively validates the logic of the build architecture in a short amount of time.


### Accelerator features
  - Tests both REST and SOAP calls
  - Predefined test steps
  - Predefined assertions
  - Soft assertion
  - Generating test reports
  - Jenkins pipeline integration
  - Environment agnostic
  - Parallel execution

## Built with
* **RESTAssured** - for testing the API services [https://rest-assured.io/](https://rest-assured.io/)
* **Cucumber** - for BDD approach [https://cucumber.io/](https://cucumber.io/)
* **Gradle** - build management tool [https://gradle.org/](https://gradle.org/)
* **Hamcrest** - for asserting the API responses [http://hamcrest.org/JavaHamcrest/tutorial](http://hamcrest.org/JavaHamcrest/tutorial)
* **Allure** - for reporting the test results [https://docs.qameta.io/allure/](https://docs.qameta.io/allure/)


## Getting Started

Follow these instructions to get a microservices accelerator up and running and testing on your local machine.

### Prerequisites

- JDK 11+
- Gradle 6.1+
- IDE (IntelliJ or Eclipse with Cucumber Plugin)

### Installation

- Install Java and set path.
- Install Gradle and set path.
- Clone the repository using git.
    - git clone <url>


<!-- USAGE EXAMPLES -->
## Usage

This accelerator is specifically designed to perform functional testing REST or SOAP API's:


1. Perform functional test for given application.
2. Provide sample test to start the the API functional testing.

### Writing a test

* The test case (cucumber feature file) goes in the `features` library and should have the ".feature" extension.

* You can start writing test using reference at `features/createuser.feature`. You can extend this feature or make your own features using some of the predefined cucumber steps.

### Testing environment information

This accelerator is environment agnostic. You can provide the environment information under **src/test/resources/config/envconfig.yml** file

```
commonconfigs:
   relaxed_https: 'true'
   url_encoding_enabled: 'true'
   max_timeout: '60'
   polling_time: '5'
 
qaenv:
   host_uri: 'https://jsonplaceholder.typicode.com'
   context_path: '/comments'
   follow_redirects: 'false'
   proxy: 'http://localhost:8080/'
 
devenv:
   host_uri: 'https://jsonplaceholder.typicode.com'
   context_path: '/comments'
   follow_redirects: 'false'
   proxy: 'http://localhost:8080/'`
```

### API test information 

As mentioned in the sample, the accelerator file will know which API to test. We just need to provide the API information. 

* **src/test/resources/apischema/env_name(devenv | qaenv)/jsonplaceholder**

    * **request.json** this file contains the api information
        * ```
          {
            "base_path": "{{context_path}}", --> context_path value will be picked from src/test/resources/config/envconfig.yml file
            "header": {
              "Content-Type": "application/json"  --> Default Header Values
            },
            "request": {
              "name": "microservice_test_accelerator" --> Actual API Schema
            }
          }
          ```
        * There is host and proxy configuration in the env file and for any API you want. Hit the API with a different host or disbale the proxy for that API to make this change request.json
           ```
          {
            "host_uri": "https://xyz.com", --> This will change the host call for this  APi
            "base_path": "{{context_path}}", --> context_path value will be picked from src/test/resources/config/envconfig.yml file
            "proxy_disabled": "true", --> This will disable the proxy configuration only for this API call
            "header": {
                "Content-Type": "application/json"  --> Default Header Values
            },
            "request": {
                "name": "microservice_test_accelerator" --> Actual API Schema
            }
          }
           ```
              
    * **request_response_mapping.yml** this file contains request key mapping information against the response and verification of the expected matching key  and actual value in test
        * ```
          CreateUser:
            'name': 'name'
          ```
    * **testdata.yml** this file contains the test data information to run an API test (feature file)
        * ```
          User1:
            name: 'microservice_test_accelerator'
          ```
          
### Sample Feature file to understand the keywords

```
Feature: User registration
# In this example we're setting the API name to 'jsonplaceholder' - the test will automatically pick the 'User1' data from testdata.yml file and replace the values in request template and hit the endpoint based on the 'host_uri' in 'envconfig.yml' file under 'resources/config' and base_path in request.json template. base_path value will also drive from envconfig.yml

# In the last step we are verifying the response against the complete request. The test will pick the key from 'request_response_mapping.yml' under the resources/schema/<env> and will verify the response value againt the request

  @regression
  Scenario Outline: User Post Details
    Given I have API "<API>" --> This step will Understand which API to test. "jsonplaceholder" API information Exists under the src/test/resources/apischema/env_name/jsonplaceholder
    And I set content-type as JSON
    And I set request body for "<RequestBody>" --> This step will Understand which Test data to use for API to test. API Test data information Exists under the src/test/resources/apischema/env_name/jsonplaceholder/testdata.yml and will user the "User1" Testdata from testdata.yml file
    When I call method POST --> This step will perofrm the API POST Operation
    Then I verify response code is 201
    Then I verify "CreateUser" in Response --> This step will verify the reponse verfication against the simple request being sent, This step will understand to pick the request reponse mapping from src/test/resources/apischema/env_name/jsonplaceholder/request_response_mapping.yml  and perform the verification for each key mapping present in request_response_mapping.yml file.
    Examples:
      | API             | RequestBody |
      | jsonplaceholder | User1       |
```


```
Feature: Customer Login
# This is how background can be used to eliminate duplicate steps
# For these 2 scenarios, the user should go to the login page first.
Background:
   User navigates to Login Page
   Given I am on login page

# Scenario with AND
Scenario:
   When I enter username as "TOM"
   And I enter password as "JERRY"
   Then Login should fail

# Scenario with BUT
Scenario:
   When I enter username as "TOM"
   And I enter password as "JERRY"
   Then Login should fail
   But Re-login option should be available
```

### Key Words used in Cucumber feature files

- Feature (A suitable name for your scenarios in the feature file)
- Scenario (A suitable name for the scenario you are trying to write)
- Given, When, Then, And, But (step keywords to describe the flow)
- Background (Common step to run for all scenarios in that feature file)
- Scenario Outline
- Examples (Using Scenario Outline and Examples, scenario can be repeated with multiple values from Examples table)
- | (Data Tables) - Data Tables can be used to pass multiple values in the same step
- @ (Tags) - Particular scenario/feature can be executed by running with tags.
- '#' can be used to provide Comments
Cucumber Tutorials: [https://docs.cucumber.io/guides/10-minute-tutorial/](https://docs.cucumber.io/guides/10-minute-tutorial/)


### Running tests

There are two ways to run the test from this project

1. RunCucumberTest java file at location **src/test/java/com/microservice/test/accelerator/runner/RunCucumberTest.java**
    1. You can provide the test tag information in Runner file and Just Run the Test using Java File
    2. By Default the Env name is Selected in file **src/main/java/com/microservice/test/accelerator/constants/ConfigConstants.java**
        ```
       String DEFAULT_ENV = "qaenv";
       ```
      
2. Using command line: Go to your project directory from terminal and execute following commands
    * `gradle cucumber` to run all the tests on default env
    * `gradle cucumber -Denv.type=<env_name> -Dtags=@<tag_name>` to run the specific tests on given env_name
    * `gradle cucumber -Denv.type=<env_name>` to run all the tests on given env

### Test reports
 This accelerator supports test reporting using default cucumner reports and Allure reporting
 
 #### Default Cucumber report
  You can find the basic Cucumber report under **target/cucumber/cucumber-report.html**
  
  ![Cucumber Reort](https://lion.box.com/shared/static/qn5yjpvyamebazmvskw4e8ykzd1w36bo.png)
  
  #### Allure reporting
  This accelerator also integrates with the Allure reporting framework. You can find the report after the Tests Execution
  * directory for Allure report in the current project, **build/reports/allure-report/index.html** by default
  
  ![Allure Report](https://lion.box.com/shared/static/rxa38fjz36rh0nbrepobljv6ae09xwxy.png)
  
  ![Allure Report](https://lion.box.com/shared/static/z3qlsu377soyd9aeg4icm1cf2djsz2nf.png)

## FAQs
**Q:** Does this Accelerator Support all HTTP status codes assertion
 
**A:** Yes, We can assert any HTTP status code using common step **Then I verify response code is 201**
 
 ##
**Q:** Does this Accelerator has Ability to manage test data across multiple Environment
 
 **A:** Yes, You can manage the test data for each environments under **src/test/resources/apischema/<env_name>**
 
 ##
**Q:** Does this Accelerator Environment Agnostic
 
**A:** Yes, You can provide multiple environments configuration in **src/test/resources/config/envconfig.yml**
 
 ##
**Q:** Does this Accelerator Support Parallel Execution of Tests
 
**A:** Yes, This Accelerator supports parallel Execution of Tests, you need to provide cucumber **--thread** count in build file cucumber options
   ```
   args = ['--plugin', 'pretty', '--plugin' , 'json:target/cucumber.json', '--plugin' , 'io.qameta.allure.cucumber4jvm.AllureCucumber4Jvm' , '--glue', 'com.microservice.test.accelerator.stepdefs', 'src/test/resources/features' , --threads,'5']
   ```
 ##
 
**Q:** Does this Accelerator has In-built Test Reporting 
 
**A:** Yes, This Accelerator Support Default Cucumber Reporting as well As Allure Reporting
 
 ##
**Q:** Does this Accelerator has ability to evaluate headers and cookies
 
**A:** Yes, you can evaluate any headers and cookeis of api under test and save it in testcontext for further use.

 ##
 
**Q:** Does this Accelerator supports Schema Validation
 
**A:** Yes, This Accelerator Support Schema Validation using JSON Schema Validation with Rest-Assured

<!-- CONTRIBUTING -->
## Contributing

Contributions are what make the open source community such an amazing place to be learn, inspire, and create. Any contributions you make are **greatly appreciated**.

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request


## Contact
[Sumit Sharma](mailto:sumit.sharma31@publicissapient.com)
